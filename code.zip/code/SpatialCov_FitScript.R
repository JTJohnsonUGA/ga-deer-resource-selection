##Load Data
#SiteA summer
load(file="jd_ch_SiteA_summer.gzip")
load(file="ji_ch_SiteA_summer.gzip")
load(file="jp_SiteA.gzip")
load(file="M_SiteA.gzip")

#SiteA winter
load(file="jd_ch_SiteA_winter.gzip")
load(file="ji_ch_SiteA_winter.gzip")

#SiteB summer
load(file="jd_ch_SiteB_summer.gzip")
load(file="ji_ch_SiteB_summer.gzip")
load(file="jp_SiteB.gzip")
load(file="M_SiteB.gzip")

#SiteB winter
load(file="jd_ch_SiteB_winter.gzip")
load(file="ji_ch_SiteB_winter.gzip")

#SiteC summer
load(file="jd_ch_SiteC_summer.gzip")
load(file="ji_ch_SiteC_summer.gzip")
load(file="jp_SiteC.gzip")
load(file="M_SiteC.gzip")

#SiteC winter
load(file="jd_ch_SiteC_winter.gzip")
load(file="ji_ch_SiteC_winter.gzip")

#SiteD summer
load(file="jd_ch_SiteD_summer.gzip")
load(file="ji_ch_SiteD_summer.gzip")
load(file="jp_SiteD.gzip")
load(file="M_SiteD.gzip")

#SiteD winter
load(file="jd_ch_SiteD_winter.gzip")
load(file="ji_ch_SiteD_winter.gzip")

#### FIT model ####
library(parallel)
#library(rjags)
#load.module("glm")

#SiteA summer
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteA_summer", "ji_ch_SiteA_summer", "jp_SiteA", "M_SiteA"))

out1.SiteA_summer <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  #fit model
  jm2.ch.SiteA_summer <- jags.model(file= "SCR_model.jag", jd_ch_SiteA_summer, ji_ch_SiteA_summer,n.adapt=200, n.chains=1) 
  jc2.SiteA_summer <- coda.samples(jm2.ch.SiteA_summer, c(jp_SiteA, "w1"), 10000)
  return(as.mcmc(jc2.SiteA_summer))
})
stopCluster(c1)
save(out1.SiteA_summer, file="out1.SiteA_summer")

## SiteA winter
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteA_winter", "ji_ch_SiteA_winter", "jp_SiteA", "M_SiteA"))

out1.SiteA_winter <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  #fit model
  jm2.ch.SiteA_winter <- jags.model(file= "SCR_model.jag", jd_ch_SiteA_winter, ji_ch_SiteA_winter, n.adapt=200, n.chains=1)
  jc2.SiteA_winter <- coda.samples(jm2.ch.SiteA_winter, c(jp_SiteA, "w1"), 10000)
  return(as.mcmc(jc2.SiteA_winter))
})

stopCluster(c1)
save(out1.SiteA_winter, file="out1.SiteA_winter")


##SiteB summer
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteB_summer", "ji_ch_SiteB_summer", "jp_SiteB", "M_SiteB"))

out1.SiteB_summer <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  #fit model
  jm2.ch.SiteB_summer <- jags.model(file= "SCR_model.jag", jd_ch_SiteB_summer, ji_ch_SiteB_summer,n.adapt=200, n.chains=1)
  jc2.SiteB_summer <- coda.samples(jm2.ch.SiteB_summer, jp_SiteB, 10000)
  return(as.mcmc(jc2.SiteB_summer))
})

stopCluster(c1)
save(out1.SiteB_summer, file="out1.SiteB_summer")

##SiteB winter
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteB_winter", "ji_ch_SiteB_winter", "jp_SiteB", "M_SiteB"))

out1.SiteB_winter <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  #fit model
  jm2.ch.SiteB_winter <- jags.model(file= "SCR_model.jag", jd_ch_SiteB_winter, ji_ch_SiteB_winter,n.adapt=200, n.chains=1)
  jc2.SiteB_winter <- coda.samples(jm2.ch.SiteB_winter, jp_SiteB, 10000)
  return(as.mcmc(jc2.SiteB_winter))
})

stopCluster(c1)
save(out1.SiteB_winter, file="out1.SiteB_winter")

##SiteC summer
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteC_summer", "ji_ch_SiteC_summer", "jp_SiteC", "M_SiteC"))

out1.SiteC_summer <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  #fit model
  jm2.ch.SiteC_summer <- jags.model(file= "SCR_model.jag", jd_ch_SiteC_summer, ji_ch_SiteC_summer,n.adapt=200, n.chains=1)
  jc2.SiteC_summer <- coda.samples(jm2.ch.SiteC_summer, jp_SiteC, 10000)
  return(as.mcmc(jc2.SiteC_summer))
})

stopCluster(c1)
save(out1.SiteC_summer, file="out1.SiteC_summer")

##SiteC winter
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteC_winter", "ji_ch_SiteC_winter", "jp_SiteC", "M_SiteC"))

out1.SiteC_winter <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  load.module("dic")
  #fit model
  jm2.ch.SiteC_winter <- jags.model(file= "SCR_model.jag", jd_ch_SiteC_winter, ji_ch_SiteC_winter,n.adapt=200, n.chains=1)
  jc2.SiteC_winter <- coda.samples(jm2.ch.SiteC_winter, jp_SiteC, 10000)
  return(as.mcmc(jc2.SiteC_winter))
})

stopCluster(c1)
save(out1.SiteC_winter, file="out1.SiteC_winter")

##SiteD summer
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteD_summer", "ji_ch_SiteD_summer", "jp_SiteD", "M_SiteD"))

out1.SiteD_summer <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  #fit model
  jm2.ch.SiteD_summer <- jags.model(file= "SCR_model.jag", jd_ch_SiteD_summer, ji_ch_SiteD_summer,n.adapt=200, n.chains=1)
  jc2.SiteD_summer <- coda.samples(jm2.ch.SiteD_summer, jp_SiteD, 10000)
  return(as.mcmc(jc2.SiteD_summer))
})

stopCluster(c1)
save(out1.SiteD_summer, file="out1.SiteD_summer")

##SiteD winter
c1 <- makeCluster(2)
clusterExport(c1, c("jd_ch_SiteD_winter", "ji_ch_SiteD_winter", "jp_SiteD", "M_SiteD"))

out1.SiteD_winter <- clusterEvalQ(c1, {
  library(rjags)
  load.module("glm")
  #fit model
  jm2.ch.SiteD_winter <- jags.model(file= "SCR_model.jag", jd_ch_SiteD_winter, ji_ch_SiteD_winter,n.adapt=200, n.chains=1)
  jc2.SiteD_winter <- coda.samples(jm2.ch.SiteD_winter, jp_SiteD, 10000)
  return(as.mcmc(jc2.SiteD_winter))
})

stopCluster(c1)
save(out1.SiteD_winter, file="out1.SiteD_winter")





